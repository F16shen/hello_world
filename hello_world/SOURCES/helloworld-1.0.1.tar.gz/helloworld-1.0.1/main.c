#include"print.h"
int main(void){
	printhello();
	return 0;
}
