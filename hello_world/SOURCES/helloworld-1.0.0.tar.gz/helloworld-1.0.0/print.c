#include"print.h"
void printhello(){
	printf("hello,world\n");
}
